import sqlite3
db = sqlite3.connect('db.db', check_same_thread=False)
sql = db.cursor()

token = '5252524796:AAFdZ90QDv2p6COIxtVhL-VBIk5fG_rwttE'

admins = [717778881]

username_bot = 'share_bot'

global link_channel
link_channel = ''